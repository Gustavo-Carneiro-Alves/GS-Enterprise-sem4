﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace GSGreenCycle.Migrations
{
    /// <inheritdoc />
    public partial class RecomecoCerto : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
