﻿namespace GS_GreenCycle.Models
{
    public class Suporte
    {
        public string Problema { get; set; }
    }
}
