﻿namespace GS_GreenCycle.Enums
{
    public enum PerfilEnum
    {
        Admin = 1,
        Padrao = 2
    }
}
